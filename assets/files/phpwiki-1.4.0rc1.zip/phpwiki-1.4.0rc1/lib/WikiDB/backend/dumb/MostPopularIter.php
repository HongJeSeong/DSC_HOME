<?php // -*-php-*-
// rcs_id('$Id: MostPopularIter.php 7638 2010-08-11 11:58:40Z vargenau $');

require_once('lib/WikiDB/backend.php');


/**
 * An inefficient but general most_popular iterator.
 *
 * This iterator will work with any backend which implements the
 * backend::get_all_pages() and backend::get_pagedata()
 * methods.
 */
class WikiDB_backend_dumb_MostPopularIter
extends WikiDB_backend_iterator
{
    function WikiDB_backend_dumb_MostPopularIter($backend, &$all_pages, $limit) {
        $this->_pages = array();
        $pages = &$this->_pages;

        while ($page = $all_pages->next()) {
            if (!isset($page['pagedata']))
                $page['pagedata'] = $backend->get_pagedata($page['pagename']);
            $pages[] = $page;
        }

        if($limit < 0){  //sort pages in reverse order - ie least popular first.
            usort($pages, 'WikiDB_backend_dumb_MostPopularIter_sortf_rev');
            $limit = -$limit;
        }
        else usort($pages, 'WikiDB_backend_dumb_MostPopularIter_sortf');

        if ($limit < 0) {
            $pages = array_reverse($pages);
            $limit = -$limit;
        }

        if ($limit && $limit < count($pages))
            array_splice($pages, $limit);
    }

    function next() {
        return array_shift($this->_pages);
    }
  
    function free() {
        unset($this->_pages);
    }
}

function WikiDB_backend_dumb_MostPopularIter_sortf($a,$b) {
    $ahits = $bhits = 0;
    if (isset($a['pagedata']['hits']))
        $ahits = (int)$a['pagedata']['hits'];
    if (isset($b['pagedata']['hits']))
        $bhits = (int)$b['pagedata']['hits'];
    return $bhits - $ahits;
}

function WikiDB_backend_dumb_MostPopularIter_sortf_rev($a,$b) {
    $ahits = $bhits = 0;
    if (isset($a['pagedata']['hits']))
        $ahits = (int)$a['pagedata']['hits'];
    if (isset($b['pagedata']['hits']))
        $bhits = (int)$b['pagedata']['hits'];
    return $ahits - $bhits;
}

// Local Variables:
// mode: php
// tab-width: 8
// c-basic-offset: 4
// c-hanging-comment-ender-p: nil
// indent-tabs-mode: nil
// End:
?>
