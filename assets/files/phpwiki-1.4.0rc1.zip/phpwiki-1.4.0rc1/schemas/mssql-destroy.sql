-- $Id: mssql-destroy.sql 6203 2008-08-26 13:23:56Z vargenau $

DROP TABLE page;
DROP TABLE version;
DROP TABLE recent;
DROP TABLE nonempty;
DROP TABLE link;
DROP TABLE session;

DROP TABLE pref;
--DROP TABLE user;
DROP TABLE member;

-- wikilens theme
DROP TABLE rating;

DROP TABLE accesslog;
