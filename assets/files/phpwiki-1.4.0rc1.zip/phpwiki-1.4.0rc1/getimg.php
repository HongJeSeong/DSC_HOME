<?php // -*-php-*- $Id: getimg.php 7181 2009-10-05 14:25:48Z vargenau $ 
include ("index.php");
include "lib/imagecache.php";
?>
