<?php // -*-php-*- $Id: wiki2public.php 7181 2009-10-05 14:25:48Z vargenau $
  // cronjob script to copy pages marked as "public" to a seperate public wiki area.
  // If ENABLE_PAGE_PUBLIC = true
  // can only run via localhost for security reasons
?>
